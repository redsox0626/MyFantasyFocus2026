//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-I45g_nfB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DIpdEf5t.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DIpdEf5t.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DeOtRGiZ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
