import { i as __toESM } from "../_runtime.mjs";
import { a as KICKOFF_WINDOWS, c as SEASON_START_LABEL, d as findGameForTeam, g as teamsInSlot, h as normalizeNflTeam, l as TIME_SLOTS, m as kickoffLabel, o as POSITION_LABEL, p as isIdpPosition, s as POSITION_ORDER, u as classifySlot } from "./schedule-BXgrYzwn.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, r as number, t as _enum } from "../_libs/zod.mjs";
import { a as LoaderCircle, c as ChevronDown, i as Radio, n as Trophy, o as LayoutGrid, s as ChevronUp, t as X } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay$1, h as Slot, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as cn } from "./router-RWpYu47V.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DKz5r1xm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-[background-color,color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 active:enabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow-border hover:bg-primary/90",
			secondary: "bg-surface text-fg shadow-border hover:bg-subtle",
			outline: "bg-transparent text-fg shadow-border hover:bg-subtle",
			ghost: "text-muted hover:bg-subtle hover:text-fg",
			mine: "bg-mine text-mine-fg hover:opacity-90",
			theirs: "bg-theirs text-theirs-fg hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-bg/80 data-[state=open]:animate-in data-[state=closed]:animate-out", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-1/2 top-1/2 z-50 w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2", "rounded-2xl bg-elevated p-5 text-fg shadow-border", "focus:outline-none", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-3 top-3 rounded-md p-2 text-muted hover:bg-subtle hover:text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-4 space-y-1 pr-8", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-xl font-semibold tracking-tight text-fg", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm text-muted text-pretty", className),
		...props
	});
}
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	type,
	className: cn("flex h-11 w-full rounded-lg bg-surface px-3 text-sm text-fg shadow-border", "placeholder:text-muted", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", "disabled:cursor-not-allowed disabled:opacity-50", className),
	ref,
	...props
}));
Input.displayName = "Input";
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("text-xs font-medium tracking-wide text-muted", className),
	...props
}));
Label.displayName = "Label";
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getBootstrap = createServerFn({ method: "GET" }).handler(createSsrRpc("0a25e930827fb0f3144bef45b9cfc0ce5f1a032abad79564eb7b0e4ec44e9447"));
var espnCreds = object({
	leagueId: string().min(1),
	espn_s2: string().optional(),
	swid: string().optional(),
	teamId: string().optional()
});
var getEspnTeams = createServerFn({ method: "POST" }).validator(object({
	leagueId: string().regex(/^\d+$/, "League ID must be numeric"),
	espn_s2: string().optional(),
	swid: string().optional()
})).handler(createSsrRpc("26c449fad815004f33a5935a96b3a508965a80f1e1a185c307b9140acc282662"));
var runAnalysis = createServerFn({ method: "POST" }).validator(object({
	platform: _enum([
		"sleeper",
		"espn",
		"both"
	]),
	week: number().int().min(1).max(18),
	sleeperUsernames: string().optional(),
	espn: espnCreds.optional()
})).handler(createSsrRpc("d8c2015cfab9ed22853e4ef74e389aaed027105c33eabef89c10815e6cd8e628"));
function EspnDialog({ open, onOpenChange, onConnected }) {
	const [leagueId, setLeagueId] = (0, import_react.useState)("");
	const [espnS2, setEspnS2] = (0, import_react.useState)("");
	const [swid, setSwid] = (0, import_react.useState)("");
	const [showPrivate, setShowPrivate] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	async function handleConnect() {
		if (!/^\d+$/.test(leagueId.trim())) {
			setError("League ID must be numeric.");
			return;
		}
		setLoading(true);
		setError(null);
		try {
			const result = await getEspnTeams({ data: {
				leagueId: leagueId.trim(),
				espn_s2: espnS2.trim() || void 0,
				swid: swid.trim() || void 0
			} });
			onConnected({
				leagueId: leagueId.trim(),
				espn_s2: espnS2.trim(),
				swid: swid.trim(),
				teamId: result.teams[0] ? String(result.teams[0].id) : void 0
			}, result.teams);
			onOpenChange(false);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not reach this ESPN league.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Connect ESPN" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Paste the league ID from your ESPN fantasy URL. Public leagues need nothing else." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "league-id",
						children: "League ID"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "league-id",
						inputMode: "numeric",
						placeholder: "123456789",
						value: leagueId,
						onChange: (e) => setLeagueId(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setShowPrivate((v) => !v),
					className: "text-xs text-muted underline-offset-2 hover:text-fg hover:underline",
					children: showPrivate ? "Hide private-league cookies" : "Private league? Add cookies"
				}),
				showPrivate ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 rounded-xl bg-surface p-3 shadow-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "From a logged-in browser: Application → Cookies → espn_s2 and SWID. Stored only on this device."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "espn-s2",
								children: "espn_s2"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "espn-s2",
								autoCapitalize: "none",
								autoCorrect: "off",
								placeholder: "Cookie value",
								value: espnS2,
								onChange: (e) => setEspnS2(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "swid",
								children: "SWID"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "swid",
								autoCapitalize: "none",
								autoCorrect: "off",
								placeholder: "{A1B2C3D4-...}",
								value: swid,
								onChange: (e) => setSwid(e.target.value)
							})]
						})
					]
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-theirs",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full",
					onClick: handleConnect,
					disabled: loading,
					children: loading ? "Connecting…" : "Connect league"
				})
			]
		})] })
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium tabular-nums", {
	variants: { variant: {
		default: "bg-subtle text-fg",
		muted: "bg-subtle text-muted",
		mine: "bg-mine text-mine-fg",
		theirs: "bg-theirs text-theirs-fg",
		shared: "bg-shared text-shared-fg",
		outline: "shadow-border text-muted"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function tagForm(tag, matchups) {
	const matchup = matchups.find((m) => m.id === tag.matchupId);
	if (!matchup || matchup.status === "pending" || matchup.status === "tied") return matchup?.status ?? "pending";
	if (tag.side === "mine") return matchup.status;
	return matchup.status === "winning" ? "losing" : "winning";
}
function cardForm(tags, matchups) {
	if (!tags?.length) return void 0;
	const forms = tags.map((t) => tagForm(t, matchups)).filter((s) => s === "winning" || s === "losing");
	if (!forms.length) return void 0;
	if (forms.every((s) => s === "winning")) return "winning";
	if (forms.every((s) => s === "losing")) return "losing";
	return "mixed";
}
function formatScore(n) {
	if (!Number.isFinite(n)) return "0";
	return n.toFixed(n % 1 === 0 ? 0 : 1);
}
function overlapTone(player) {
	const my = player.myCount || 0;
	const opp = player.oppCount || 0;
	if (my > opp) return "mine";
	if (opp > my) return "theirs";
	return "shared";
}
function PlayerCard({ player, overlap, matchups }) {
	const tone = overlap ? overlapTone(player) : void 0;
	const tags = player.tags?.length ? player.tags : (player.teamAbbr || "").split(",").filter(Boolean).map((abbrev) => ({
		abbrev,
		name: abbrev,
		side: "mine",
		platform: "sleeper",
		matchupId: ""
	}));
	const form = cardForm(player.tags, matchups);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("rounded-lg bg-surface px-3 py-2.5 shadow-border", tone === "mine" && "bg-mine-wash", tone === "theirs" && "bg-theirs-wash", tone === "shared" && "bg-shared-wash", form === "winning" && "shadow-win", form === "losing" && "shadow-lose", form === "mixed" && "shadow-mixed"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-start justify-between gap-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-medium text-fg",
						children: player.playerNameOnly
					}), player.count > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: tone ?? "muted",
						className: "shrink-0",
						children: ["×", player.count]
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-0.5 truncate text-xs text-muted tabular-nums",
					children: [player.nflTeam, player.kickoff ? ` · ${player.kickoff}` : ""]
				})]
			})
		}), tags.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 flex flex-wrap gap-1",
			children: tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				title: tag.name,
				className: cn("rounded-md px-1.5 py-0.5 font-mono text-[10px] tracking-wide", overlap && tag.side === "mine" && "bg-mine text-mine-fg", overlap && tag.side === "theirs" && "bg-theirs text-theirs-fg", (!overlap || tag.side !== "mine" && tag.side !== "theirs") && "bg-subtle text-muted"),
				children: tag.abbrev
			}, `${tag.matchupId}-${tag.side}-${tag.abbrev}`))
		}) : null]
	});
}
function groupByPosition(players) {
	const known = new Set(POSITION_ORDER);
	const groups = POSITION_ORDER.map((pos) => ({
		pos,
		players: players.filter((p) => p.position === pos)
	})).filter((g) => g.players.length > 0);
	const extra = players.filter((p) => !known.has(p.position));
	if (extra.length) groups.push({
		pos: "IDP",
		players: extra
	});
	return groups;
}
function Column({ title, hint, players, tone, overlap, matchups }) {
	const groups = groupByPosition(players);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex min-w-0 flex-1 flex-col rounded-2xl bg-elevated p-3 shadow-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: cn("flex items-center justify-between rounded-xl px-3 py-2.5", tone === "mine" && "bg-mine text-mine-fg", tone === "theirs" && "bg-theirs text-theirs-fg", tone === "shared" && "bg-shared text-shared-fg"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-semibold leading-tight tracking-tight",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] opacity-80",
				children: hint
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tabular-nums text-sm font-medium",
				children: players.length
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex flex-1 flex-col gap-4",
			children: players.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-2 py-8 text-center text-sm text-muted",
				children: "No starters in this slot."
			}) : groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "px-1 text-[11px] font-medium uppercase tracking-[0.14em] text-muted",
					children: [
						POSITION_LABEL[group.pos] ?? group.pos,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [
								"(",
								group.players.length,
								")"
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: group.players.map((player) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerCard, {
						player,
						overlap,
						matchups
					}, `${player.id}-${player.platform}-${player.teamAbbr}`))
				})]
			}, group.pos))
		})]
	});
}
function LineupBoard({ my, overlap, opponent, matchups }) {
	const [col, setCol] = (0, import_react.useState)("my");
	const tabs = [
		{
			id: "my",
			label: "My guys",
			count: my.length
		},
		{
			id: "overlap",
			label: "Both",
			count: overlap.length
		},
		{
			id: "opponent",
			label: "Theirs",
			count: opponent.length
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-1 rounded-xl bg-elevated p-1 shadow-border lg:hidden",
				children: tabs.map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setCol(tab.id),
					className: cn("flex h-11 flex-col items-center justify-center rounded-lg text-xs font-medium", col === tab.id ? "bg-surface text-fg" : "text-muted"),
					children: [tab.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-[10px] opacity-70",
						children: tab.count
					})]
				}, tab.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:hidden",
				children: [
					col === "my" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Column, {
						title: "My guys",
						hint: "You start them",
						players: my,
						tone: "mine",
						matchups
					}) : null,
					col === "overlap" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Column, {
						title: "Both",
						hint: "Started on both sides",
						players: overlap,
						tone: "shared",
						overlap: true,
						matchups
					}) : null,
					col === "opponent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Column, {
						title: "Their guys",
						hint: "Opponent starts them",
						players: opponent,
						tone: "theirs",
						matchups
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden gap-3 lg:grid lg:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Column, {
						title: "My guys",
						hint: "You start them",
						players: my,
						tone: "mine",
						matchups
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Column, {
						title: "Both",
						hint: "Started on both sides",
						players: overlap,
						tone: "shared",
						overlap: true,
						matchups
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Column, {
						title: "Their guys",
						hint: "Opponent starts them",
						players: opponent,
						tone: "theirs",
						matchups
					})
				]
			})
		]
	});
}
function ScoresBoard({ matchups }) {
	if (!matchups.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "rounded-2xl bg-elevated px-4 py-10 text-center shadow-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "No matchups yet. Analyze lineups to see live scores."
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: matchups.map((m) => {
			const opp = m.oppTeam;
			const mineLead = m.status === "winning";
			const theirsLead = m.status === "losing";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-2xl bg-elevated p-3 shadow-border sm:p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-[11px] font-medium uppercase tracking-[0.14em] text-muted",
							children: m.leagueName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "muted",
							children: m.platform === "espn" ? "ESPN" : "Sleeper"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[1fr_auto_1fr] items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: cn("min-w-0 rounded-xl px-3 py-2.5", mineLead ? "bg-mine text-mine-fg" : "bg-surface"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-display text-base font-semibold tracking-tight",
										children: m.myTeam.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-[10px] tracking-wide opacity-70",
										children: m.myTeam.abbrev
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 font-display text-2xl font-semibold tabular-nums leading-none",
										children: formatScore(m.myTeam.score)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-muted",
								children: "vs"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: cn("min-w-0 rounded-xl px-3 py-2.5 text-right", theirsLead ? "bg-theirs text-theirs-fg" : "bg-surface"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-display text-base font-semibold tracking-tight",
										children: opp?.name ?? "Bye"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-[10px] tracking-wide opacity-70",
										children: opp?.abbrev ?? "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 font-display text-2xl font-semibold tabular-nums leading-none",
										children: opp ? formatScore(opp.score) : "—"
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-center text-[11px] text-muted",
						children: m.status === "winning" ? "You’re ahead" : m.status === "losing" ? "You’re behind" : m.status === "tied" ? "Tied" : "Waiting on kickoff"
					})
				]
			}, m.id);
		})
	});
}
function TimeSlotBar({ value, onChange, counts, liveCount = 0 }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const windowSelected = value !== "All" && value !== "Live";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			role: "tablist",
			"aria-label": "Kickoff window",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "tab",
					"aria-selected": value === "Live",
					onClick: () => onChange("Live"),
					className: cn("flex h-11 min-w-11 shrink-0 items-center gap-1.5 rounded-full px-4 text-sm", "transition-[background-color,color,transform] duration-150 ease-out active:scale-[0.96]", value === "Live" ? "bg-mine text-mine-fg" : "bg-surface text-muted shadow-border hover:text-fg"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: cn("size-3.5", liveCount > 0 && value !== "Live" && "text-mine") }),
						"Live",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums opacity-80",
							children: liveCount
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": value === "All",
					onClick: () => onChange("All"),
					className: cn("h-11 shrink-0 rounded-full px-4 text-sm", "transition-[background-color,color,transform] duration-150 ease-out active:scale-[0.96]", value === "All" ? "bg-primary text-primary-foreground" : "bg-surface text-muted shadow-border hover:text-fg"),
					children: "All"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-expanded": open,
					onClick: () => setOpen((v) => !v),
					className: cn("flex h-11 min-w-0 flex-1 items-center justify-center gap-1.5 rounded-full px-3 text-sm", "transition-[background-color,color,transform] duration-150 ease-out active:scale-[0.96]", windowSelected ? "bg-primary text-primary-foreground" : "bg-surface text-muted shadow-border hover:text-fg"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: windowSelected ? value : "Other windows"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-4 shrink-0 transition-transform duration-150", open && "rotate-180") })]
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
			children: KICKOFF_WINDOWS.map((slot) => {
				const selected = value === slot;
				const count = counts?.[slot];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						onChange(slot);
						setOpen(false);
					},
					className: cn("flex h-11 items-center justify-between rounded-xl px-3 text-left text-sm", selected ? "bg-primary text-primary-foreground" : "bg-surface text-fg shadow-border"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: slot
					}), typeof count === "number" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-xs opacity-70",
						children: count
					}) : null]
				}, slot);
			})
		}) : null]
	});
}
function parseNames(value) {
	return value.split(/[,\n]/).map((s) => s.trim().replace(/^@/, "")).filter(Boolean);
}
function UsernameField({ value, onChange }) {
	const names = parseNames(value);
	const [draft, setDraft] = (0, import_react.useState)("");
	function commit(raw) {
		const next = raw.trim().replace(/^@/, "");
		if (!next) return;
		if (names.some((n) => n.toLowerCase() === next.toLowerCase())) {
			setDraft("");
			return;
		}
		onChange([...names, next].join(", "));
		setDraft("");
	}
	function remove(name) {
		onChange(names.filter((n) => n !== name).join(", "));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: "usernames",
				children: "Sleeper accounts"
			}),
			names.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: names.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex h-8 items-center gap-1 rounded-full bg-surface pl-3 pr-1 text-xs text-fg shadow-border",
					children: [name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": `Remove ${name}`,
						onClick: () => remove(name),
						className: "flex size-6 items-center justify-center rounded-full text-muted hover:bg-subtle hover:text-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
					})]
				}, name))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "usernames",
				autoCapitalize: "none",
				autoCorrect: "off",
				spellCheck: false,
				placeholder: names.length ? "Add another username" : "sleeper username",
				value: draft,
				onChange: (e) => setDraft(e.target.value),
				onKeyDown: (e) => {
					if (e.key === "Enter" || e.key === ",") {
						e.preventDefault();
						commit(draft);
					}
					if (e.key === "Backspace" && !draft && names.length) remove(names[names.length - 1]);
				},
				onBlur: () => commit(draft)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "Press enter to add. We pull every 2026 league those managers are in."
			})
		]
	});
}
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	ref,
	className: cn("peer inline-flex h-7 w-12 shrink-0 cursor-pointer items-center rounded-full shadow-border transition-colors duration-150", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", "disabled:cursor-not-allowed disabled:opacity-50", "data-[state=checked]:bg-mine data-[state=unchecked]:bg-subtle", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("pointer-events-none block size-5 rounded-full bg-fg shadow-sm transition-transform duration-150", "data-[state=checked]:translate-x-6 data-[state=unchecked]:translate-x-1") })
}));
Switch.displayName = Switch$1.displayName;
function tags(...items) {
	return items;
}
function p(partial) {
	return {
		count: 0,
		platform: "sleeper",
		playerNameOnly: partial.name,
		...partial
	};
}
var my = [
	p({
		id: "demo-maye",
		name: "D. Maye",
		position: "QB",
		teamAbbr: "KINGS,SUNSET",
		nflTeam: "NE",
		count: 2,
		tags: tags({
			abbrev: "KINGS",
			name: "Kings",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-kings"
		}, {
			abbrev: "SUNSET",
			name: "Sunset",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-sunset"
		})
	}),
	p({
		id: "demo-allen",
		name: "J. Allen",
		position: "QB",
		teamAbbr: "KINGS",
		nflTeam: "BUF",
		tags: tags({
			abbrev: "KINGS",
			name: "Kings",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-kings"
		})
	}),
	p({
		id: "demo-achane",
		name: "D. Achane",
		position: "RB",
		teamAbbr: "KINGS,SUNSET",
		nflTeam: "MIA",
		count: 2,
		tags: tags({
			abbrev: "KINGS",
			name: "Kings",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-kings"
		}, {
			abbrev: "SUNSET",
			name: "Sunset",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-sunset"
		})
	}),
	p({
		id: "demo-gibbs",
		name: "J. Gibbs",
		position: "RB",
		teamAbbr: "SUNSET",
		nflTeam: "DET",
		tags: tags({
			abbrev: "SUNSET",
			name: "Sunset",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-sunset"
		})
	}),
	p({
		id: "demo-chase",
		name: "J. Chase",
		position: "WR",
		teamAbbr: "KINGS",
		nflTeam: "CIN",
		tags: tags({
			abbrev: "KINGS",
			name: "Kings",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-kings"
		})
	}),
	p({
		id: "demo-arsb",
		name: "A. St. Brown",
		position: "WR",
		teamAbbr: "SUNSET",
		nflTeam: "DET",
		tags: tags({
			abbrev: "SUNSET",
			name: "Sunset",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-sunset"
		})
	}),
	p({
		id: "demo-btj",
		name: "B. Thomas Jr.",
		position: "WR",
		teamAbbr: "KINGS",
		nflTeam: "JAX",
		tags: tags({
			abbrev: "KINGS",
			name: "Kings",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-kings"
		})
	}),
	p({
		id: "demo-bowers",
		name: "B. Bowers",
		position: "TE",
		teamAbbr: "SUNSET",
		nflTeam: "LV",
		tags: tags({
			abbrev: "SUNSET",
			name: "Sunset",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-sunset"
		})
	}),
	p({
		id: "demo-aubrey",
		name: "B. Aubrey",
		position: "K",
		teamAbbr: "KINGS",
		nflTeam: "DAL",
		tags: tags({
			abbrev: "KINGS",
			name: "Kings",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-kings"
		})
	}),
	p({
		id: "demo-bills",
		name: "Buffalo",
		position: "DEF",
		teamAbbr: "SUNSET",
		nflTeam: "BUF",
		tags: tags({
			abbrev: "SUNSET",
			name: "Sunset",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-sunset"
		})
	}),
	p({
		id: "demo-parsons",
		name: "M. Parsons",
		position: "LB",
		teamAbbr: "KINGS",
		nflTeam: "GB",
		tags: tags({
			abbrev: "KINGS",
			name: "Kings",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-kings"
		})
	}),
	p({
		id: "demo-hutch",
		name: "A. Hutchinson",
		position: "DL",
		teamAbbr: "SUNSET",
		nflTeam: "DET",
		tags: tags({
			abbrev: "SUNSET",
			name: "Sunset",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-sunset"
		})
	})
];
var overlap = [
	p({
		id: "demo-cmc",
		name: "C. McCaffrey",
		position: "RB",
		teamAbbr: "KINGS,THEBOY",
		nflTeam: "SF",
		platform: "both",
		myCount: 2,
		oppCount: 1,
		count: 3,
		tags: tags({
			abbrev: "KINGS",
			name: "Kings",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-kings"
		}, {
			abbrev: "THEBOY",
			name: "The Boys",
			side: "theirs",
			platform: "sleeper",
			matchupId: "demo-kings"
		})
	}),
	p({
		id: "demo-jj",
		name: "J. Jefferson",
		position: "WR",
		teamAbbr: "KINGS,RIVERS",
		nflTeam: "MIN",
		platform: "both",
		myCount: 1,
		oppCount: 1,
		count: 2,
		tags: tags({
			abbrev: "KINGS",
			name: "Kings",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-kings"
		}, {
			abbrev: "RIVERS",
			name: "Rivers",
			side: "theirs",
			platform: "sleeper",
			matchupId: "demo-sunset"
		})
	}),
	p({
		id: "demo-lamb",
		name: "C. Lamb",
		position: "WR",
		teamAbbr: "SUNSET,THEBOY",
		nflTeam: "DAL",
		platform: "both",
		myCount: 1,
		oppCount: 2,
		count: 3,
		tags: tags({
			abbrev: "SUNSET",
			name: "Sunset",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-sunset"
		}, {
			abbrev: "THEBOY",
			name: "The Boys",
			side: "theirs",
			platform: "sleeper",
			matchupId: "demo-kings"
		})
	}),
	p({
		id: "demo-kelce",
		name: "T. Kelce",
		position: "TE",
		teamAbbr: "KINGS,RIVERS",
		nflTeam: "KC",
		platform: "both",
		myCount: 1,
		oppCount: 1,
		count: 2,
		tags: tags({
			abbrev: "KINGS",
			name: "Kings",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-kings"
		}, {
			abbrev: "RIVERS",
			name: "Rivers",
			side: "theirs",
			platform: "sleeper",
			matchupId: "demo-sunset"
		})
	}),
	p({
		id: "demo-walker",
		name: "K. Walker",
		position: "RB",
		teamAbbr: "KINGS,THEBOY",
		nflTeam: "SEA",
		platform: "both",
		myCount: 1,
		oppCount: 1,
		count: 2,
		tags: tags({
			abbrev: "KINGS",
			name: "Kings",
			side: "mine",
			platform: "sleeper",
			matchupId: "demo-kings"
		}, {
			abbrev: "THEBOY",
			name: "The Boys",
			side: "theirs",
			platform: "sleeper",
			matchupId: "demo-kings"
		})
	})
];
var DEMO_RESULT = {
	my,
	opponent: [
		p({
			id: "demo-hurts",
			name: "J. Hurts",
			position: "QB",
			teamAbbr: "THEBOY",
			nflTeam: "PHI",
			tags: tags({
				abbrev: "THEBOY",
				name: "The Boys",
				side: "theirs",
				platform: "sleeper",
				matchupId: "demo-kings"
			})
		}),
		p({
			id: "demo-nix",
			name: "B. Nix",
			position: "QB",
			teamAbbr: "RIVERS",
			nflTeam: "DEN",
			tags: tags({
				abbrev: "RIVERS",
				name: "Rivers",
				side: "theirs",
				platform: "sleeper",
				matchupId: "demo-sunset"
			})
		}),
		p({
			id: "demo-saquon",
			name: "S. Barkley",
			position: "RB",
			teamAbbr: "THEBOY,RIVERS",
			nflTeam: "PHI",
			count: 2,
			tags: tags({
				abbrev: "THEBOY",
				name: "The Boys",
				side: "theirs",
				platform: "sleeper",
				matchupId: "demo-kings"
			}, {
				abbrev: "RIVERS",
				name: "Rivers",
				side: "theirs",
				platform: "sleeper",
				matchupId: "demo-sunset"
			})
		}),
		p({
			id: "demo-puka",
			name: "P. Nacua",
			position: "WR",
			teamAbbr: "THEBOY",
			nflTeam: "LAR",
			tags: tags({
				abbrev: "THEBOY",
				name: "The Boys",
				side: "theirs",
				platform: "sleeper",
				matchupId: "demo-kings"
			})
		}),
		p({
			id: "demo-mhj",
			name: "M. Harrison Jr.",
			position: "WR",
			teamAbbr: "RIVERS",
			nflTeam: "ARI",
			tags: tags({
				abbrev: "RIVERS",
				name: "Rivers",
				side: "theirs",
				platform: "sleeper",
				matchupId: "demo-sunset"
			})
		}),
		p({
			id: "demo-jsw",
			name: "J. Smith-Njigba",
			position: "WR",
			teamAbbr: "THEBOY",
			nflTeam: "SEA",
			tags: tags({
				abbrev: "THEBOY",
				name: "The Boys",
				side: "theirs",
				platform: "sleeper",
				matchupId: "demo-kings"
			})
		}),
		p({
			id: "demo-mcbride",
			name: "T. McBride",
			position: "TE",
			teamAbbr: "THEBOY",
			nflTeam: "ARI",
			tags: tags({
				abbrev: "THEBOY",
				name: "The Boys",
				side: "theirs",
				platform: "sleeper",
				matchupId: "demo-kings"
			})
		}),
		p({
			id: "demo-tucker",
			name: "J. Tucker",
			position: "K",
			teamAbbr: "RIVERS",
			nflTeam: "BAL",
			tags: tags({
				abbrev: "RIVERS",
				name: "Rivers",
				side: "theirs",
				platform: "sleeper",
				matchupId: "demo-sunset"
			})
		}),
		p({
			id: "demo-eagles",
			name: "Philadelphia",
			position: "DEF",
			teamAbbr: "THEBOY",
			nflTeam: "PHI",
			tags: tags({
				abbrev: "THEBOY",
				name: "The Boys",
				side: "theirs",
				platform: "sleeper",
				matchupId: "demo-kings"
			})
		}),
		p({
			id: "demo-crosby",
			name: "M. Crosby",
			position: "DL",
			teamAbbr: "THEBOY",
			nflTeam: "LV",
			tags: tags({
				abbrev: "THEBOY",
				name: "The Boys",
				side: "theirs",
				platform: "sleeper",
				matchupId: "demo-kings"
			})
		})
	],
	overlap,
	matchups: [{
		id: "demo-kings",
		platform: "sleeper",
		leagueName: "Sibling Rivalry",
		myTeam: {
			name: "Kings",
			abbrev: "KINGS",
			score: 104.2
		},
		oppTeam: {
			name: "The Boys",
			abbrev: "THEBOY",
			score: 91
		},
		status: "winning"
	}, {
		id: "demo-sunset",
		platform: "sleeper",
		leagueName: "The Degenerates",
		myTeam: {
			name: "Sunset",
			abbrev: "SUNSET",
			score: 78.4
		},
		oppTeam: {
			name: "Rivers",
			abbrev: "RIVERS",
			score: 88.1
		},
		status: "losing"
	}],
	meta: {
		week: 1,
		season: "2026",
		sleeperLeagues: 2,
		espnUsed: false,
		warnings: ["Sample Week 1 slate — connect Sleeper or ESPN to analyze your real lineups."],
		liveTeams: ["SEA", "NE"]
	}
};
var ESPN_KEY = "mff.espn.credentials";
var SLEEPER_KEY = "mff.sleeper.usernames";
var PLATFORM_KEY = "mff.platform";
var IDP_KEY = "mff.showIdp";
function loadEspnCredentials() {
	try {
		const raw = localStorage.getItem(ESPN_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!parsed?.leagueId) return null;
		return parsed;
	} catch {
		return null;
	}
}
function saveEspnCredentials(creds) {
	localStorage.setItem(ESPN_KEY, JSON.stringify(creds));
}
function clearEspnCredentials() {
	localStorage.removeItem(ESPN_KEY);
}
function loadSleeperUsernames() {
	try {
		return localStorage.getItem(SLEEPER_KEY) ?? "";
	} catch {
		return "";
	}
}
function saveSleeperUsernames(value) {
	localStorage.setItem(SLEEPER_KEY, value);
}
function loadPlatform() {
	try {
		const v = localStorage.getItem(PLATFORM_KEY);
		if (v === "sleeper" || v === "espn" || v === "both") return v;
	} catch {}
	return "sleeper";
}
function savePlatform(platform) {
	localStorage.setItem(PLATFORM_KEY, platform);
}
function loadShowIdp() {
	try {
		const v = localStorage.getItem(IDP_KEY);
		if (v === "0") return false;
		if (v === "1") return true;
	} catch {}
	return true;
}
function saveShowIdp(value) {
	localStorage.setItem(IDP_KEY, value ? "1" : "0");
}
var PLATFORMS = [
	{
		id: "sleeper",
		label: "Sleeper"
	},
	{
		id: "espn",
		label: "ESPN"
	},
	{
		id: "both",
		label: "Both"
	}
];
function annotatePlayers(players, bootstrap, week) {
	if (!bootstrap) return players;
	return players.map((player) => {
		const game = findGameForTeam(bootstrap.schedule, week, player.nflTeam);
		return {
			...player,
			kickoff: game ? kickoffLabel(game.start_time) : player.nflTeam && player.nflTeam !== "FA" ? "Bye" : player.kickoff,
			slot: game ? classifySlot(game) : player.slot
		};
	});
}
function applyPlayerFilters(players, opts) {
	let list = players;
	if (!opts.showIdp) list = list.filter((p) => !isIdpPosition(p.position));
	if (opts.filter === "All") return list;
	if (opts.filter === "Live") return list.filter((p) => opts.liveTeams.has(normalizeNflTeam(p.nflTeam)));
	return list.filter((p) => opts.teams.has(normalizeNflTeam(p.nflTeam)));
}
function slotCounts(result, bootstrap, week, showIdp) {
	const all = [
		...result.my,
		...result.overlap,
		...result.opponent
	].filter((p) => showIdp || !isIdpPosition(p.position));
	const counts = { All: all.length };
	if (!bootstrap) return counts;
	for (const slot of TIME_SLOTS) {
		if (slot === "All") continue;
		const teams = teamsInSlot(bootstrap.schedule, week, slot);
		counts[slot] = all.filter((p) => teams.has(normalizeNflTeam(p.nflTeam))).length;
	}
	return counts;
}
function HomeScreen() {
	const [bootstrap, setBootstrap] = (0, import_react.useState)(null);
	const [bootError, setBootError] = (0, import_react.useState)(null);
	const [platform, setPlatform] = (0, import_react.useState)("sleeper");
	const [usernames, setUsernames] = (0, import_react.useState)("");
	const [week, setWeek] = (0, import_react.useState)(1);
	const [espnCreds, setEspnCreds] = (0, import_react.useState)(null);
	const [espnTeams, setEspnTeams] = (0, import_react.useState)([]);
	const [espnOpen, setEspnOpen] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [result, setResult] = (0, import_react.useState)(null);
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [collapsed, setCollapsed] = (0, import_react.useState)(false);
	const [showIdp, setShowIdp] = (0, import_react.useState)(true);
	const [view, setView] = (0, import_react.useState)("lineups");
	(0, import_react.useEffect)(() => {
		setPlatform(loadPlatform());
		setUsernames(loadSleeperUsernames());
		setShowIdp(loadShowIdp());
		const stored = loadEspnCredentials();
		if (stored) {
			setEspnCreds(stored);
			getEspnTeams({ data: {
				leagueId: stored.leagueId,
				espn_s2: stored.espn_s2 || void 0,
				swid: stored.swid || void 0
			} }).then((r) => setEspnTeams(r.teams)).catch(() => void 0);
		}
		getBootstrap().then((data) => {
			setBootstrap(data);
			setWeek(data.state.week || 1);
		}).catch((err) => {
			setBootError(err instanceof Error ? err.message : "Could not load NFL week.");
		});
	}, []);
	const season = bootstrap?.state.season || String(2026);
	const showSleeper = platform === "sleeper" || platform === "both";
	const showEspn = platform === "espn" || platform === "both";
	const liveTeams = (0, import_react.useMemo)(() => {
		const fromResult = result?.meta.liveTeams || [];
		const fromBoot = bootstrap?.liveTeams || [];
		return new Set((fromResult.length ? fromResult : fromBoot).map(normalizeNflTeam));
	}, [result, bootstrap]);
	const filtered = (0, import_react.useMemo)(() => {
		if (!result) return null;
		const teams = filter !== "All" && filter !== "Live" ? teamsInSlot(bootstrap?.schedule || [], result.meta.week, filter) : /* @__PURE__ */ new Set();
		const opts = {
			filter,
			teams,
			liveTeams,
			showIdp
		};
		return {
			my: applyPlayerFilters(result.my, opts),
			overlap: applyPlayerFilters(result.overlap, opts),
			opponent: applyPlayerFilters(result.opponent, opts)
		};
	}, [
		result,
		filter,
		bootstrap,
		liveTeams,
		showIdp
	]);
	const counts = result ? slotCounts(result, bootstrap, result.meta.week, showIdp) : void 0;
	const livePlayerCount = result ? [
		...result.my,
		...result.overlap,
		...result.opponent
	].filter((p) => (showIdp || !isIdpPosition(p.position)) && liveTeams.has(normalizeNflTeam(p.nflTeam))).length : 0;
	function persistPlatform(next) {
		setPlatform(next);
		savePlatform(next);
	}
	function persistIdp(next) {
		setShowIdp(next);
		saveShowIdp(next);
	}
	async function handleAnalyze() {
		if (showSleeper && !usernames.trim()) {
			toast.error("Enter at least one Sleeper username.");
			return;
		}
		if (showEspn && !espnCreds) {
			toast.error("Connect an ESPN league first.");
			setEspnOpen(true);
			return;
		}
		setLoading(true);
		try {
			saveSleeperUsernames(usernames);
			const data = await runAnalysis({ data: {
				platform,
				week,
				sleeperUsernames: usernames,
				espn: espnCreds ? {
					leagueId: espnCreds.leagueId,
					teamId: espnCreds.teamId,
					espn_s2: espnCreds.espn_s2 || void 0,
					swid: espnCreds.swid || void 0
				} : void 0
			} });
			setResult(data);
			setCollapsed(true);
			setView("lineups");
			for (const warning of data.meta.warnings) toast.message(warning);
			toast.success(`Week ${data.meta.week} · ${data.my.length} yours, ${data.overlap.length} shared, ${data.opponent.length} theirs`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Analysis failed.");
		} finally {
			setLoading(false);
		}
	}
	function loadDemo() {
		const w = week;
		const demo = {
			my: annotatePlayers(DEMO_RESULT.my, bootstrap, w),
			opponent: annotatePlayers(DEMO_RESULT.opponent, bootstrap, w),
			overlap: annotatePlayers(DEMO_RESULT.overlap, bootstrap, w),
			matchups: DEMO_RESULT.matchups,
			meta: {
				...DEMO_RESULT.meta,
				week: w,
				season
			}
		};
		setResult(demo);
		setCollapsed(true);
		setFilter("All");
		setView("lineups");
		toast.message("Sample Week 1 slate — connect a real league to replace it.");
	}
	function handleEspnConnected(creds, teams) {
		setEspnCreds(creds);
		setEspnTeams(teams);
		saveEspnCredentials(creds);
		toast.success(`Connected ESPN league ${creds.leagueId}`);
	}
	function disconnectEspn() {
		clearEspnCredentials();
		setEspnCreds(null);
		setEspnTeams([]);
	}
	const selectedEspnTeam = espnTeams.find((t) => String(t.id) === espnCreds?.teamId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh max-w-6xl flex-col px-4 pb-28 pt-5 sm:px-6 sm:pb-16 sm:pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-5 flex items-end justify-between gap-3 sm:mb-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] font-medium uppercase tracking-[0.22em] text-muted",
							children: ["NFL ", season]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl font-semibold tracking-tight text-fg sm:text-5xl",
							children: "My Fantasy Focus"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 hidden max-w-xl text-sm text-muted text-pretty sm:block",
							children: [
								"Stack every Sleeper and ESPN lineup, then see who you and your opponent both started. Season opens",
								" ",
								SEASON_START_LABEL,
								"."
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex h-11 shrink-0 items-center gap-2 rounded-lg bg-surface px-3 text-sm shadow-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs uppercase tracking-wide text-muted",
						children: "Wk"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "bg-transparent text-fg tabular-nums focus:outline-none",
						value: week,
						onChange: (e) => setWeek(Number(e.target.value)),
						"aria-label": "NFL week",
						children: Array.from({ length: 18 }, (_, i) => i + 1).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: n,
							className: "bg-elevated text-fg",
							children: n
						}, n))
					})]
				})]
			}),
			bootError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm text-theirs",
				children: bootError
			}) : null,
			collapsed && result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setCollapsed(false),
				className: "mb-4 flex h-11 items-center justify-center gap-2 rounded-xl bg-surface text-sm text-fg shadow-border",
				children: ["Accounts & options", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4" })]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-5 rounded-2xl bg-elevated p-4 shadow-border sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-1 rounded-xl bg-surface p-1 shadow-border",
						children: PLATFORMS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => persistPlatform(p.id),
							className: cn("h-10 rounded-lg text-sm font-medium transition-[background-color,color] duration-150", platform === p.id ? "bg-primary text-primary-foreground" : "text-muted hover:text-fg"),
							children: p.label
						}, p.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-4",
						children: [
							showSleeper ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsernameField, {
								value: usernames,
								onChange: setUsernames
							}) : null,
							showEspn ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "ESPN league" }), espnCreds ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl bg-surface p-3 shadow-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "truncate text-sm text-fg",
												children: ["League ", espnCreds.leagueId]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs text-muted",
												children: [espnCreds.espn_s2 || espnCreds.swid ? "Private" : "Public", selectedEspnTeam ? ` · ${selectedEspnTeam.name}` : ""]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex shrink-0 gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												variant: "ghost",
												size: "sm",
												onClick: () => setEspnOpen(true),
												children: "Edit"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												variant: "ghost",
												size: "sm",
												onClick: disconnectEspn,
												children: "Remove"
											})]
										})]
									}), espnTeams.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "mt-3 block",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "sr-only",
											children: "Your ESPN team"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											className: "h-11 w-full rounded-lg bg-elevated px-3 text-sm text-fg shadow-border focus:outline-none focus-visible:ring-2 focus-visible:ring-ring",
											value: espnCreds.teamId || "",
											onChange: (e) => {
												const next = {
													...espnCreds,
													teamId: e.target.value
												};
												setEspnCreds(next);
												saveEspnCredentials(next);
											},
											children: espnTeams.map((team) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: String(team.id),
												children: [
													team.name,
													" (",
													team.abbrev,
													")"
												]
											}, team.id))
										})]
									}) : null]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "secondary",
									className: "w-full",
									onClick: () => setEspnOpen(true),
									children: "Connect ESPN league"
								})]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3 rounded-xl bg-surface px-3 py-2.5 shadow-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-fg",
									children: "IDP players"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: "Linebackers, DL, and DBs"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									checked: showIdp,
									onCheckedChange: persistIdp,
									"aria-label": "Show IDP players"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: handleAnalyze,
							disabled: loading,
							className: "w-full",
							children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), "Analyzing"] }) : "Analyze lineups"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: loadDemo,
								disabled: loading,
								className: "flex-1",
								children: "Sample slate"
							}), result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								onClick: () => setCollapsed(true),
								className: "flex-1",
								children: ["Hide", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4" })]
							}) : null]
						})]
					})
				]
			}),
			result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden grid-cols-2 gap-1 rounded-xl bg-elevated p-1 shadow-border sm:grid",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewTab, {
						active: view === "lineups",
						onClick: () => setView("lineups"),
						icon: "lineups",
						label: "Lineups"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewTab, {
						active: view === "scores",
						onClick: () => setView("scores"),
						icon: "scores",
						label: "Scores"
					})]
				}), view === "lineups" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeSlotBar, {
						value: filter,
						onChange: setFilter,
						counts,
						liveCount: livePlayerCount
					}),
					result.meta.warnings.length > 0 && collapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted text-pretty",
						children: result.meta.warnings[0]
					}) : null,
					filtered ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineupBoard, {
						my: filtered.my,
						overlap: filtered.overlap,
						opponent: filtered.opponent,
						matchups: result.matchups
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-1 text-center text-xs text-muted",
						children: "Green outline = that fantasy team is winning. Red = losing. In Both, green chips are yours and red chips are the opponent."
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoresBoard, { matchups: result.matchups })]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, { onDemo: loadDemo }),
			result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)] sm:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setView("lineups"),
						className: cn("flex h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-medium", view === "lineups" ? "text-fg" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-5" }), "Lineups"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setView("scores"),
						className: cn("flex h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-medium", view === "scores" ? "text-fg" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-5" }), "Scores"]
					})]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EspnDialog, {
				open: espnOpen,
				onOpenChange: setEspnOpen,
				onConnected: handleEspnConnected
			})
		]
	});
}
function ViewTab({ active, onClick, icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex h-11 items-center justify-center gap-2 rounded-lg text-sm font-medium", active ? "bg-surface text-fg" : "text-muted hover:text-fg"),
		children: [icon === "lineups" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-4" }), label]
	});
}
function EmptyState({ onDemo }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "grid gap-3 sm:grid-cols-3",
		children: [[
			{
				title: "Pull every league",
				body: "Drop in Sleeper usernames and we walk each 2026 roster versus this week’s opponent."
			},
			{
				title: "Spot the overlap",
				body: "Players you both started land in Both — color-coded by who started them more often."
			},
			{
				title: "Live windows",
				body: "Jump to games on now, or open other kickoff windows. Watch scores while you wait."
			}
		].map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-2xl bg-elevated p-5 shadow-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold tracking-tight text-fg",
				children: card.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted text-pretty",
				children: card.body
			})]
		}, card.title)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "sm:col-span-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: onDemo,
				className: "w-full sm:w-auto",
				children: "Preview a sample Week 1 slate"
			})
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {});
}
//#endregion
export { Home as component };
