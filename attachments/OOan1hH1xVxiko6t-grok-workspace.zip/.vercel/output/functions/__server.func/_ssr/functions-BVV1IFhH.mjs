import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, r as number, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/functions-BVV1IFhH.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getBootstrap_createServerFn_handler = createServerRpc({
	id: "0a25e930827fb0f3144bef45b9cfc0ce5f1a032abad79564eb7b0e4ec44e9447",
	name: "getBootstrap",
	filename: "src/lib/fantasy/functions.ts"
}, (opts) => getBootstrap.__executeServer(opts));
var getBootstrap = createServerFn({ method: "GET" }).handler(getBootstrap_createServerFn_handler, async () => {
	const { bootstrapFantasy } = await import("./analyze.server-Ca9djuUZ.mjs");
	return bootstrapFantasy();
});
var espnCreds = object({
	leagueId: string().min(1),
	espn_s2: string().optional(),
	swid: string().optional(),
	teamId: string().optional()
});
var getEspnTeams_createServerFn_handler = createServerRpc({
	id: "26c449fad815004f33a5935a96b3a508965a80f1e1a185c307b9140acc282662",
	name: "getEspnTeams",
	filename: "src/lib/fantasy/functions.ts"
}, (opts) => getEspnTeams.__executeServer(opts));
var getEspnTeams = createServerFn({ method: "POST" }).validator(object({
	leagueId: string().regex(/^\d+$/, "League ID must be numeric"),
	espn_s2: string().optional(),
	swid: string().optional()
})).handler(getEspnTeams_createServerFn_handler, async ({ data }) => {
	const { espnTeams } = await import("./analyze.server-Ca9djuUZ.mjs");
	return espnTeams(data);
});
var runAnalysis_createServerFn_handler = createServerRpc({
	id: "d8c2015cfab9ed22853e4ef74e389aaed027105c33eabef89c10815e6cd8e628",
	name: "runAnalysis",
	filename: "src/lib/fantasy/functions.ts"
}, (opts) => runAnalysis.__executeServer(opts));
var runAnalysis = createServerFn({ method: "POST" }).validator(object({
	platform: _enum([
		"sleeper",
		"espn",
		"both"
	]),
	week: number().int().min(1).max(18),
	sleeperUsernames: string().optional(),
	espn: espnCreds.optional()
})).handler(runAnalysis_createServerFn_handler, async ({ data }) => {
	const { analyzeLineups } = await import("./analyze.server-Ca9djuUZ.mjs");
	return analyzeLineups(data);
});
//#endregion
export { getBootstrap_createServerFn_handler, getEspnTeams_createServerFn_handler, runAnalysis_createServerFn_handler };
