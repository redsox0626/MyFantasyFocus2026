import type { EspnCredentials, Platform } from "./types";

const ESPN_KEY = "mff.espn.credentials";
const SLEEPER_KEY = "mff.sleeper.usernames";
const PLATFORM_KEY = "mff.platform";
const IDP_KEY = "mff.showIdp";

export function loadEspnCredentials(): EspnCredentials | null {
  try {
    const raw = localStorage.getItem(ESPN_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as EspnCredentials;
    if (!parsed?.leagueId) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function saveEspnCredentials(creds: EspnCredentials): void {
  localStorage.setItem(ESPN_KEY, JSON.stringify(creds));
}

export function clearEspnCredentials(): void {
  localStorage.removeItem(ESPN_KEY);
}

export function loadSleeperUsernames(): string {
  try {
    return localStorage.getItem(SLEEPER_KEY) ?? "";
  } catch {
    return "";
  }
}

export function saveSleeperUsernames(value: string): void {
  localStorage.setItem(SLEEPER_KEY, value);
}

export function loadPlatform(): Platform {
  try {
    const v = localStorage.getItem(PLATFORM_KEY);
    if (v === "sleeper" || v === "espn" || v === "both") return v;
  } catch {
    /* ignore */
  }
  return "sleeper";
}

export function savePlatform(platform: Platform): void {
  localStorage.setItem(PLATFORM_KEY, platform);
}

export function loadShowIdp(): boolean {
  try {
    const v = localStorage.getItem(IDP_KEY);
    if (v === "0") return false;
    if (v === "1") return true;
  } catch {
    /* ignore */
  }
  return true;
}

export function saveShowIdp(value: boolean): void {
  localStorage.setItem(IDP_KEY, value ? "1" : "0");
}
