import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getEspnTeams } from "@/lib/fantasy/functions";
import type { EspnCredentials, EspnTeam } from "@/lib/fantasy/types";

export function EspnDialog({
  open,
  onOpenChange,
  onConnected,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConnected: (creds: EspnCredentials, teams: EspnTeam[]) => void;
}) {
  const [leagueId, setLeagueId] = useState("");
  const [espnS2, setEspnS2] = useState("");
  const [swid, setSwid] = useState("");
  const [showPrivate, setShowPrivate] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleConnect() {
    if (!/^\d+$/.test(leagueId.trim())) {
      setError("League ID must be numeric.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const result = await getEspnTeams({
        data: {
          leagueId: leagueId.trim(),
          espn_s2: espnS2.trim() || undefined,
          swid: swid.trim() || undefined,
        },
      });
      const creds: EspnCredentials = {
        leagueId: leagueId.trim(),
        espn_s2: espnS2.trim(),
        swid: swid.trim(),
        teamId: result.teams[0] ? String(result.teams[0].id) : undefined,
      };
      onConnected(creds, result.teams);
      onOpenChange(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not reach this ESPN league.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Connect ESPN</DialogTitle>
          <DialogDescription>
            Paste the league ID from your ESPN fantasy URL. Public leagues need nothing else.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="league-id">League ID</Label>
            <Input
              id="league-id"
              inputMode="numeric"
              placeholder="123456789"
              value={leagueId}
              onChange={(e) => setLeagueId(e.target.value)}
            />
          </div>
          <button
            type="button"
            onClick={() => setShowPrivate((v) => !v)}
            className="text-xs text-muted underline-offset-2 hover:text-fg hover:underline"
          >
            {showPrivate ? "Hide private-league cookies" : "Private league? Add cookies"}
          </button>
          {showPrivate ? (
            <div className="space-y-3 rounded-xl bg-surface p-3 shadow-border">
              <p className="text-xs text-muted">
                From a logged-in browser: Application → Cookies → espn_s2 and SWID. Stored only on this device.
              </p>
              <div className="space-y-1.5">
                <Label htmlFor="espn-s2">espn_s2</Label>
                <Input
                  id="espn-s2"
                  autoCapitalize="none"
                  autoCorrect="off"
                  placeholder="Cookie value"
                  value={espnS2}
                  onChange={(e) => setEspnS2(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="swid">SWID</Label>
                <Input
                  id="swid"
                  autoCapitalize="none"
                  autoCorrect="off"
                  placeholder="{A1B2C3D4-...}"
                  value={swid}
                  onChange={(e) => setSwid(e.target.value)}
                />
              </div>
            </div>
          ) : null}
          {error ? <p className="text-sm text-theirs">{error}</p> : null}
          <Button className="w-full" onClick={handleConnect} disabled={loading}>
            {loading ? "Connecting…" : "Connect league"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
