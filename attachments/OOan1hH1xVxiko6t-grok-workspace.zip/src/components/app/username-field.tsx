import { useState } from "react";
import { X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

function parseNames(value: string): string[] {
  return value
    .split(/[,\n]/)
    .map((s) => s.trim().replace(/^@/, ""))
    .filter(Boolean);
}

export function UsernameField({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  const names = parseNames(value);
  const [draft, setDraft] = useState("");

  function commit(raw: string) {
    const next = raw.trim().replace(/^@/, "");
    if (!next) return;
    if (names.some((n) => n.toLowerCase() === next.toLowerCase())) {
      setDraft("");
      return;
    }
    onChange([...names, next].join(", "));
    setDraft("");
  }

  function remove(name: string) {
    onChange(names.filter((n) => n !== name).join(", "));
  }

  return (
    <div className="space-y-2">
      <Label htmlFor="usernames">Sleeper accounts</Label>
      {names.length > 0 ? (
        <div className="flex flex-wrap gap-1.5">
          {names.map((name) => (
            <span
              key={name}
              className="inline-flex h-8 items-center gap-1 rounded-full bg-surface pl-3 pr-1 text-xs text-fg shadow-border"
            >
              {name}
              <button
                type="button"
                aria-label={`Remove ${name}`}
                onClick={() => remove(name)}
                className="flex size-6 items-center justify-center rounded-full text-muted hover:bg-subtle hover:text-fg"
              >
                <X className="size-3" />
              </button>
            </span>
          ))}
        </div>
      ) : null}
      <Input
        id="usernames"
        autoCapitalize="none"
        autoCorrect="off"
        spellCheck={false}
        placeholder={names.length ? "Add another username" : "sleeper username"}
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === ",") {
            e.preventDefault();
            commit(draft);
          }
          if (e.key === "Backspace" && !draft && names.length) {
            remove(names[names.length - 1]!);
          }
        }}
        onBlur={() => commit(draft)}
      />
      <p className="text-xs text-muted">Press enter to add. We pull every 2026 league those managers are in.</p>
    </div>
  );
}
